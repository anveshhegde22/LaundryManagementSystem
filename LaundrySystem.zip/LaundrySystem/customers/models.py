from django.db import models

# Create your models here.
class Customer(models.Model):
    name=models.CharField(max_length=255)
    mobile=models.IntegerField()
    address=models.TextField()
    service=models.TextField()

    def __str__(self):
        return str(self.name)+" "+str(self.address)

    class Meta:
        db_table='customers'