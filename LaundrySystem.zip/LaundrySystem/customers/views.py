from django.shortcuts import render,HttpResponse,redirect

from customers.form import CustomerForm

from customers.models import Customer



# Create your views here.

def index(request):



    if request.method=="POST":

        form=CustomerForm(request.POST)



        if form.is_valid():

            form.save() #persist data in database, using queryset(Django ORM API) method==> create

            return redirect('../show')

        else:

            pass

    else:

        obj=CustomerForm() #GET request, Empty form

        return render(request,'index.html',{'cus':obj}) #HTTP GET method for displaying empty form



def show(request):

    #name="TTL"

    customers=Customer.objects.all()

    return render(request,"show.html",{'cus_list':customers})



#just display a form with filled fields

def edit(request, id):

        cus = Customer.objects.get(id=id)

        return render(request,'edit.html', {'cus':cus})


def update(request, id):
    cus = Customer.objects.get(id=id)

    form = CustomerForm(request.POST, instance=cus)

    if form.is_valid():
        form.save()

        return redirect('../show')

    return render(request, 'edit.html', {'cus': cus})


def destroy(request, id):
    cus = Customer.objects.get(id=id)

    cus.delete()

    return redirect('../show')
